// src/constants/imagePath.ts
const imagePath = {
  logo: require('../assets/gabayhabits.png'), // Adjust if path differs
};

export default imagePath;
export const splashAssets = [require('../assets/gabayhabits.png')];
